SkypeBot
==============

This is SkypeBot.



Usage
-----

Here is how you use it:

 * Do something
 * Do something else
